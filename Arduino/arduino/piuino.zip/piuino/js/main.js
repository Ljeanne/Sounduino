$('#do').click(function () {
    $('#n-do')[0].play();
    $('#note p').html('DO');
});

$('#re').click(function () {
    $('#n-re')[0].play();
    $('#note p').html('RÉ');
});

$('#mi').click(function () {
    $('#n-mi')[0].play();
    $('#note p').html('MI');
});

$('#fa').click(function () {
    $('#n-fa')[0].play();
    $('#note p').html('FA');
});


